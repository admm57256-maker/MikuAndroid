M-AI Miku Android project

This Android Studio project packages the supplied Arabic M-AI Miku chat page in an Android WebView.

ONLINE + OFFLINE BEHAVIOUR
- AUTO (recommended): uses saved knowledge and local replies first; if internet is available, it can search online when needed. If the connection drops, it falls back to the saved/offline knowledge.
- OFFLINE: uses the knowledge and facts saved inside the app on the phone. It does not fetch current news, weather, or web pages.
- ONLINE: tries to use internet search. An internet connection is required.
- User-taught facts and learned search snippets are saved locally in the app's browser storage.

IMPORTANT LIMITS
- Offline answers come from the built-in knowledge and what the user teaches Miku. This is not the same as a full offline ChatGPT model.
- The optional WebLLM model needs a compatible Android WebView with WebGPU and a large download. It may not work on all phones; low-memory devices may struggle.
- Online search uses public services (Wikipedia, DuckDuckGo, and Open-Meteo). Those services can be unavailable or block requests at times.
- The app's HTML and avatar are bundled in the APK, so the basic interface and saved knowledge are available without internet.

BUILD APK
1. Install Android Studio on a computer.
2. Open the MikuAndroid folder in Android Studio.
3. Allow Gradle sync and install Android SDK 35 if requested.
4. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
5. The debug APK is normally created at app/build/outputs/apk/debug/app-debug.apk.

The app loads bundled assets through AndroidX WebKit's HTTPS asset loader so web requests have a secure app origin instead of file://. No compiled APK is included in this project archive.


تم استبدال صورة ميكو الافتراضية بالصورة التي أرسلها المستخدم (Hatsune Miku chibi).



BUILD APK WITHOUT ANDROID STUDIO (GitHub Actions)
1. Create a GitHub account and a new repository.
2. Upload the contents of this ZIP to the repository (the MikuAndroid folder and the .github folder).
3. Open the repository's Actions tab.
4. Select "Build M-AI Miku APK", then choose "Run workflow".
5. When the run finishes, open it and download the artifact named "M-AI-Miku-debug-apk".
6. Extract the downloaded artifact and install app-debug.apk on the Android phone. If Android asks, allow installation from that browser/file manager.

This workflow builds a debug APK. It does not sign a Play Store release APK.
